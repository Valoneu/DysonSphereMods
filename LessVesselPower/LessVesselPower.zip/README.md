# LessVesselPower
## How it works
This mod changes how much power logistics vessels use. The power usage is multiplied by the value you set in the config file.
## Contact 
is in DSP discord Valoneu#8617 in modding channel

# Installation
## With Mod Manager
1. Simply open the mod manager (if you don't have it install it from [here](https://dsp.thunderstore.io/package/ebkr/r2modman/)), select LessVesselPower by Valoneu, then Download.

2. If prompted to download with dependencies, select Yes.

3. Then just click Start modded, and the game will run with the mod installed.

# Changelog

v1.0.4
1. Fixed site changelog

v1.0.3
1. Updated icon
2. Fixed site changelog

v1.0.2
1. Fixed description in config

v1.0.1
1. Updated dependancy to the right one

v1.0.0
1. Initial Release



## Appreciation
I want to thank you Selsion#0769 for helping over 2 hours to help me create my first mod