# Description
- are you maxed on lvl 10k well now you are not
- increases max LVL of infinite tech to 50k

# Installation
## With Mod Manager
1. Simply open the mod manager (if you don't have it install it from [here](https://dsp.thunderstore.io/package/ebkr/r2modman/)), select MaxLVLIncrease by Valoneu, then Download.

2. If prompted to download with dependencies, select Yes.

3. Then just click Start modded, and the game will run with the mod installed.

### Contact
Valoneu#8617 on discord, im active in modding discord and in normal dyson sphere program discord

# Changelog
1.0.3 Added config

1.0.1-1.0.2 Fix when you have 10k levels before you get mod it wont let you research more

1.0.0 Initial release

