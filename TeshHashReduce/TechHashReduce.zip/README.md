# TechHashReduce
## How it works
This mod changes how much hashes is need for every science. The HashNeeded is multiplied by the value you set in the config file. It can be cheaty if you set it to 0.1 or it could be challenge if you set it to 10. Have Fun. 
## Warning
Dont install while researching technology
## Contact 
is in DSP discord Valoneu#8617 in modding channel

# Installation
## With Mod Manager
1. Simply open the mod manager (if you don't have it install it from [here](https://dsp.thunderstore.io/package/ebkr/r2modman/)), select TechHashReduce by Valoneu, then Download.

2. If prompted to download with dependencies, select Yes.

3. Then just click Start modded, and the game will run with the mod installed.

# Changelog

v1.0.3
1. Should fix 10k LVL bug

v1.0.2
1. Should fix some overflow bugs

v1.0.1
1. Added warning in desc. 

v1.0.0
1. Initial Release
