# Description
- This mod allow user to change speed of almost any building, when boosting it will give the building more (Quadratic) power draw.
- Defaul keybind to turn on/off is Lshift + alt

# Installation
## With Mod Manager
1. Simply open the mod manager (if you don't have it install it from [here](https://dsp.thunderstore.io/package/ebkr/r2modman/)), select FactoryOverclock by Valoneu, then Download.

2. If prompted to download with dependencies, select Yes.

3. Then just click Start modded, and the game will run with the mod installed.

### Contact
Valoneu#8617 on discord, im active in modding discord and in normal dyson sphere program discord

# Changelog
1.0.3 - 1.0.4 Added multiplier for sorters(inserters)

1.0.1 - 1.0.2 Fixed dependencies, fixed thunderstore page, inscreased powerdraw to quadratic from linear, made defaul keybind Lshift + alt from Capslock + alt

1.0.0 Initial release

### Credit
- I want to thank you Semar#1983 for making this mod possible and helping me so much.

