# Description
- This mod allow user to change speed of almost any building, when boosting it will give the building more (Quadratic) power draw.
- Defaul keybind to turn on/off is Lshift + alt

# Installation
## With Mod Manager
1. Simply open the mod manager (if you don't have it install it from [here](https://dsp.thunderstore.io/package/ebkr/r2modman/)), select FactoryOverclock by Valoneu, then Download.

2. If prompted to download with dependencies, select Yes.

3. Then just click Start modded, and the game will run with the mod installed.

### Contact
Valoneu#8617 on discord, im active in modding discord and in normal dyson sphere program discord

# Changelog
1.1.6 maybe minor ups gain 

1.1.5 fixed for game version 0.9.25.11996

1.1.4 fixed lab productivity not being faster with overclock

1.1.3 fixed sorter not being fast enough, added power draw multiplier

1.1.2 fixed messing it up max consumption for gigastations

1.1.0 - 1.1.1 added overclock for generators / changed how config file looks so you need to delete and generate it again

1.0.9 decreased power draw cause it was too insane

1.0.8 fixed ray receivers not multiplying

1.0.7 fixed inserters copying with shift click only to lenght of 1

1.0.6 fixed railsguns not showing the speed, fixed power multiplier, fixed labs in research mode to draw not multiplied power draw

1.0.5 fixed labs not working, silos desc.

1.0.3 - 1.0.4 Added multiplier for sorters(inserters)

1.0.1 - 1.0.2 Fixed dependencies, fixed thunderstore page, inscreased powerdraw to quadratic from linear, made defaul keybind Lshift + alt from Capslock + alt

1.0.0 Initial release

### Credit
- I want to thank you Semar#1983 for making this mod possible and helping me so much.

