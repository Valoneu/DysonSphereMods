# Original mod
if you are Warning525 and want me to delete this mod write me on discord
Original mod: https://dsp.thunderstore.io/package/waRNing525/FactoryMutiplier/

# Supported mods
1. https://dsp.thunderstore.io/package/kremnev8/BetterMachines/
if you want me to add support for more write me on discord

# Installation
## With Mod Manager
1. Simply open the mod manager (if you don't have it install it from [here](https://dsp.thunderstore.io/package/ebkr/r2modman/)), select TechHashReduce by Valoneu, then Download.

2. If prompted to download with dependencies, select Yes.

3. Then just click Start modded, and the game will run with the mod installed.

### Contact
Valoneu#8617 on discord, im active in modding discord and in normal dyson sphere program discord

# Changelog
1.0.0 Initial release
